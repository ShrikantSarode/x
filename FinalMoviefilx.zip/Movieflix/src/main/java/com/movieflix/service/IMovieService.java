package com.movieflix.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.movieflix.dto.MovieDto;
import com.movieflix.dto.MoviePageDto;

public interface IMovieService {

	// add new movie
	MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException;

	// all movies
	List<MovieDto> all();

	// get movie by id
	MovieDto getMovie(Integer id);

	// get movie by title
	MovieDto getMovieByTitle(String title);

	// get movie by category
	List<MovieDto> getMovieByCategory(String category);

	// delete movie by id
	String deleteMovieById(Integer id);

	// update movie by id
	MovieDto updateMovie(Integer id, MovieDto updatedMovieDto, MultipartFile newPoster) throws IOException;

	// movie with pagination
	MoviePageDto moviesWithPagination(Integer pageNo, Integer pageSize);

	// movies with pagination and sorting
	MoviePageDto moviesWithPaginationAndSorting(Integer pageNo, Integer pageSize, String sortDir, String sortBy);

}
