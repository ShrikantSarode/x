package com.movieflix.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import com.movieflix.dao.CategoryRepository;
import com.movieflix.dao.GenreRepository;
import com.movieflix.dao.MovieRepository;
import com.movieflix.dto.MovieDto;
import com.movieflix.dto.MoviePageDto;
import com.movieflix.entity.Category;
import com.movieflix.entity.Genre;
import com.movieflix.entity.Movie;
import com.movieflix.exceptions.ResourceNotFoundException;

@Service
public class MovieService implements IMovieService {

	@Autowired
	private FileService fileService;

	@Autowired
	private GenreRepository genreRepository;

	@Autowired
	private MovieRepository movieRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Value("${file.upload.path}")
	private String uploadPath;

	@Override
	public MovieDto add(MovieDto movieDto, MultipartFile poster) throws IOException {

		// 1.upload poster for relative entity
		String uploadedFile = fileService.upload(poster);

//		2.set uploaded file name to MovieDto
		movieDto.setPoster(uploadedFile);

//		3.Get the Category or save the category if it is new 
		Category category = categoryRepository.findByName(movieDto.getCategory().getName())
				.orElseGet(() -> categoryRepository.save(movieDto.getCategory()));

//		4.get the genres or save genres if they are new 

		Set<Genre> genres = movieDto.getGenres().stream()
				.map(genre -> genreRepository.findByName(genre.getName()).orElseGet(() -> genreRepository.save(genre)))
				.collect(Collectors.toSet());

//		5. Convert MovieDto to Movie

		Movie newMovie = new Movie();
		newMovie.setTitle(movieDto.getTitle());
		newMovie.setDirector(movieDto.getDirector());
		newMovie.setStudio(movieDto.getStudio());
		newMovie.setReleaseDate(movieDto.getReleaseDate());
		newMovie.setAvgVote(movieDto.getAvgVote());
		newMovie.setCast(movieDto.getCast());
		newMovie.setCategory(category);

		newMovie.setGenres(genres);
		newMovie.setPoster(movieDto.getPoster());

//		6.save the movie
		Movie savedMovie = movieRepository.save(newMovie);
//		7.create poster URL with poster of saved movie 

		String posterUrl = "http://localhost:8086/file/" + savedMovie.getPoster();

//		8. convert Movie to MovieDto

		MovieDto dto = MovieDto.builder().id(savedMovie.getId()).title(savedMovie.getTitle())
				.director(savedMovie.getDirector()).studio(savedMovie.getStudio()).avgVote(savedMovie.getAvgVote())
				.releaseDate(savedMovie.getReleaseDate()).cast(savedMovie.getCast()).category(savedMovie.getCategory())
				.genres(savedMovie.getGenres()).poster(savedMovie.getPoster()).posterUrl(posterUrl).build();

//		9.return MovieDto
		return dto;
	}

	private MovieDto convertMovieToMovieDto(Movie movie) {
		String posterUrl = "http://localhost:8086/file/" + movie.getPoster(); // Create posterUrl dynamically

		return MovieDto.builder().id(movie.getId()) // Use 'movie' instead of 'savedMovie'
				.title(movie.getTitle()).director(movie.getDirector()).studio(movie.getStudio())
				.avgVote(movie.getAvgVote()).releaseDate(movie.getReleaseDate()).cast(movie.getCast())
				.category(movie.getCategory()).genres(movie.getGenres()).poster(movie.getPoster()).posterUrl(posterUrl) // Use
																														// the
																														// dynamically
																														// created
																														// posterUrl
				.build();
	}

	@Override
	public List<MovieDto> all() {
		List<Movie> movies = movieRepository.findAll();

		return movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
	}

	@Override
	public MovieDto getMovie(Integer id) {
		Movie found = movieRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Movie not found with id: " + id));

		return convertMovieToMovieDto(found);
	}

	@Override
	public MovieDto getMovieByTitle(String title) {
		Movie found = movieRepository.findByTitle(title)
				.orElseThrow(() -> new ResourceNotFoundException("Movie not found with title: " + title));

		return convertMovieToMovieDto(found);
	}

	@Override
	public List<MovieDto> getMovieByCategory(String category) {

		Category foundCategory = categoryRepository.findByName(category)
				.orElseThrow(() -> new ResourceNotFoundException("Category not found with name: " + category));

		List<Movie> movies = movieRepository.findByCategory(foundCategory);

		return movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();
	}

	@Override
	public String deleteMovieById(Integer id) {
		Movie found = movieRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Movie not found with id, Delete Aborted: " + id));

		movieRepository.delete(found);
		return "Deleted Successfully Movie Of Id:" + id;
	}

	@Override
	public MovieDto updateMovie(Integer id, MovieDto updatedMovieDto, MultipartFile newPoster) throws IOException {
//	1.check and get movie available or not by id if not throw exception
		Movie existingMovie = movieRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Movie not found with this id: " + id));
//		2. if new poster is no null then update new poster by existing poster

		if (newPoster != null) {
			String storePath = uploadPath + File.separator + existingMovie.getPoster();

			Boolean isDeleted = Files.deleteIfExists(Paths.get(storePath));

			if (isDeleted) {
				String uploadedFileName = fileService.upload(newPoster);
				// 3.set newly uploaded poster name to updateMovieDto
				updatedMovieDto.setPoster(uploadedFileName);
			} else {
				updatedMovieDto.setPoster(existingMovie.getPoster());
			}
		}

//		4.get the category or save the category if it is new
		Category category = categoryRepository.findByName(updatedMovieDto.getCategory().getName())
				.orElseGet(() -> categoryRepository.save(updatedMovieDto.getCategory()));

//		5.get the genre or save genre if they are new 
		Set<Genre> genres = updatedMovieDto.getGenres().stream()
				.map(genre -> genreRepository.findByName(genre.getName()).orElseGet(() -> genreRepository.save(genre)))
				.collect(Collectors.toSet());

//		6.set updated data to existing movie
		existingMovie.setAvgVote(updatedMovieDto.getAvgVote());
		existingMovie.setCategory(category);
		existingMovie.setGenres(genres);
		existingMovie.setReleaseDate(updatedMovieDto.getReleaseDate());
		existingMovie.setPoster(updatedMovieDto.getPoster());

//		7.save existing movie
		Movie updatedMovie = movieRepository.save(existingMovie);
//		8.convert updated movie into movieDto and return

		return convertMovieToMovieDto(updatedMovie);
	}

	@Override
	public MoviePageDto moviesWithPagination(Integer pageNo, Integer pageSize) {

//		1.create page with page size and number 

		Pageable pageable = PageRequest.of(pageNo, pageSize);

//		2.get all movies and store in pages 

		Page<Movie> moviePage = movieRepository.findAll(pageable);

//		3.get page related data
		int totalPages = moviePage.getTotalPages();
		long totalMovies = moviePage.getTotalElements();
		int size = moviePage.getSize();
		boolean isFirst = moviePage.isFirst();
		boolean isLast = moviePage.isLast();
		List<Movie> movies = moviePage.getContent();
		int currentPage = moviePage.getNumber();

//		4.convert movies to movieDtos
		List<MovieDto> movieDtos = movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();

		if (CollectionUtils.isEmpty(movieDtos)) {
			throw new ResourceNotFoundException("Movie not available on this page");
		}

//		5.return page related data with movieDtos
		return MoviePageDto.builder().currentPage(currentPage).movieDtos(movieDtos).size(size).totalMovies(totalMovies)
				.totalPages(totalPages).isFirst(isFirst).isLast(isLast).build();

	}

	@Override
	public MoviePageDto moviesWithPaginationAndSorting(Integer pageNo, Integer pageSize, String sortDir,
			String sortBy) {

//		1.create sort according direction and property
		Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

		Pageable pageable = PageRequest.of(pageNo, pageSize, sort);

		Page<Movie> moviePage = movieRepository.findAll(pageable);

//		3.get page related data
		int totalPages = moviePage.getTotalPages();
		long totalMovies = moviePage.getTotalElements();
		int size = moviePage.getSize();
		boolean isFirst = moviePage.isFirst();
		boolean isLast = moviePage.isLast();
		List<Movie> movies = moviePage.getContent();
		int currentPage = moviePage.getNumber();

//		4.convert movies to movieDtos
		List<MovieDto> movieDtos = movies.stream().map(movie -> convertMovieToMovieDto(movie)).toList();

		if (CollectionUtils.isEmpty(movieDtos)) {
			throw new ResourceNotFoundException("Movie not available on this page");
		}

//		5.return page related data with movieDtos
		return MoviePageDto.builder().currentPage(currentPage).movieDtos(movieDtos).size(size).totalMovies(totalMovies)
				.totalPages(totalPages).isFirst(isFirst).isLast(isLast).build();
	}

}
