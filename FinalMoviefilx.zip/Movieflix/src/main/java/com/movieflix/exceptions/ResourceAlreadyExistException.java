package com.movieflix.exceptions;

public class ResourceAlreadyExistException extends RuntimeException {

	public ResourceAlreadyExistException() {
		// TODO Auto-generated constructor stub
	}

	public ResourceAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
