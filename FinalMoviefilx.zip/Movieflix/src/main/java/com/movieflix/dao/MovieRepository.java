package com.movieflix.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movieflix.entity.Category;
import com.movieflix.entity.Movie;

//movie and its primary key
public interface MovieRepository extends JpaRepository<Movie, Integer> {

	// select a from movie m where m.title = ?1;
	Optional<Movie> findByTitle(String title);

	// select a from movie m where m.category = ?1;
	List<Movie> findByCategory(Category category);
}
