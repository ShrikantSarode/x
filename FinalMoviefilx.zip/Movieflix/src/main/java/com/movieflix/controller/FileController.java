package com.movieflix.controller;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.movieflix.service.FileService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/file")
public class FileController {

	@Autowired // dependency injection
	private FileService fileService;

//http://localhost:8086/file/upload
	@PostMapping("/upload")
	public ResponseEntity<?> uploadPoster(@RequestParam MultipartFile poster) throws IOException {

		if (poster.isEmpty()) {
			throw new RuntimeException("Poster is Empty!!");
		}
		String uploadedFileName = fileService.upload(poster);
		return new ResponseEntity<>(uploadedFileName, HttpStatus.CREATED);
	}

	// http://localhost:8086/file/MovieFlixLogo.png
	@GetMapping("/{fileName}")
	public ResponseEntity<?> getUplodedFile(@PathVariable String fileName, HttpServletResponse response)
			throws IOException {
		InputStream poster = fileService.getPoster(fileName);
		String contentType = getFileContentType(fileName);
		response.setContentType(contentType);
		return new ResponseEntity<>(StreamUtils.copy(poster, response.getOutputStream()), HttpStatus.OK);

	}

	private String getFileContentType(String fileName) {

		// movieFlixlogo.png
		Integer dotIndex = fileName.lastIndexOf(".");
		String extension = fileName.substring(dotIndex); // .png
		String type = null;

		switch (extension) {
		case ".png":
			type = "image/png";
			break;

		case ".jpg":
		case ".jpeg":
			type = "image/jpeg";
			break;

		default:
			type = "image/jpeg";
		}

		return type;
	}
}
